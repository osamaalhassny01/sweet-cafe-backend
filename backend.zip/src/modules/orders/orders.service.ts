import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { OrderStatus, OrderType, Prisma } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateOrderDto, CreateOrderItemDto } from './dto/create-order.dto';
import { UpdateOrderStatusDto } from './dto/update-order-status.dto';
import { OrdersGateway } from './orders.gateway';

interface CalculatedOrderItem {
  productId: string;
  productName: string;
  sizeName?: string;
  quantity: number;
  unitPrice: Prisma.Decimal;
  totalPrice: Prisma.Decimal;
  addons: Array<{ id: string; nameAr: string; nameEn: string; price: string }>;
}

@Injectable()
export class OrdersService {
  private readonly VALID_STATUS_TRANSITIONS: Record<string, Set<string>> = {
    PENDING: new Set(['CONFIRMED', 'CANCELLED']),
    NEW: new Set(['CONFIRMED', 'CANCELLED']),
    CONFIRMED: new Set(['PREPARING', 'CANCELLED']),
    PREPARING: new Set(['READY', 'CANCELLED']),
    READY: new Set(['OUT_FOR_DELIVERY', 'CANCELLED']),
    OUT_FOR_DELIVERY: new Set(['DELIVERED', 'CANCELLED']),
    DELIVERED: new Set(),
    CANCELLED: new Set(),
  };

  constructor(
    private readonly prisma: PrismaService,
    private readonly ordersGateway: OrdersGateway,
  ) {}

  async create(dto: CreateOrderDto & { offerId?: string }) {
    if (!dto.items || !dto.items.length) {
      throw new BadRequestException('Order must contain at least one item');
    }

    const calculatedItems = await this.calculateItems(dto.items);
    const subtotal = calculatedItems.reduce(
      (sum, item) => sum.plus(item.totalPrice),
      new Prisma.Decimal(0),
    );

    const zone = await this.prisma.deliveryZone.findUnique({
      where: { id: dto.deliveryZoneId },
    });

    if (!zone) {
      throw new BadRequestException('Invalid delivery zone');
    }

    if (!zone.isActive) {
      throw new BadRequestException('Delivery zone is currently inactive');
    }

    if (subtotal.lt(zone.minOrderAmount)) {
      throw new BadRequestException(
        `Minimum order amount for this zone is ${zone.minOrderAmount}`,
      );
    }

    const deliveryFee = zone.deliveryFee;
    let discount = new Prisma.Decimal(0);

    if (dto.offerId) {
      const offer = await this.prisma.offer.findUnique({
        where: { id: dto.offerId },
      });
      if (
        offer &&
        offer.isActive &&
        offer.startsAt <= new Date() &&
        offer.endsAt >= new Date()
      ) {
        discount = subtotal.mul(offer.discountPercent).div(100);
      }
    }

    const totalAmount = subtotal.plus(deliveryFee).minus(discount);
    const orderNumber = await this.nextOrderNumber();

    const order = await this.prisma.order.create({
      data: {
        orderNumber,
        customerName: dto.customerName,
        customerPhone: dto.customerPhone,
        address: dto.address,
        buildingNumber: dto.buildingNumber || '',
        floor: dto.floor || '',
        landmark: dto.landmark || '',
        latitude: dto.latitude || 0,
        longitude: dto.longitude || 0,
        deliveryZoneId: dto.deliveryZoneId,
        orderType: dto.orderType || OrderType.DELIVERY,
        notes: dto.notes || '',
        paymentMethod: dto.paymentMethod || 'CASH',
        subtotal,
        deliveryFee,
        discount,
        totalAmount,
        status: OrderStatus.PENDING,
        items: {
          create: calculatedItems.map((item) => ({
            productId: item.productId,
            productName: item.productName,
            sizeName: item.sizeName,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            totalPrice: item.totalPrice,
            addons: item.addons,
          })),
        },
      },
      include: { items: true, deliveryZone: true },
    });

    this.ordersGateway.broadcastNewOrder(order);

    return order;
  }

  async findAll(status?: string, type?: string) {
    const where: Prisma.OrderWhereInput = {};
    if (status) where.status = status as OrderStatus;
    if (type) where.orderType = type as OrderType;

    return this.prisma.order.findMany({
      where,
      include: {
        items: true,
        deliveryZone: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findByPhone(phone: string) {
    return this.prisma.order.findMany({
      where: { customerPhone: phone },
      include: {
        items: true,
        deliveryZone: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: string) {
    const order = await this.prisma.order.findUnique({
      where: { id },
      include: {
        items: true,
        deliveryZone: true,
      },
    });

    if (!order) {
      throw new NotFoundException('Order not found');
    }

    return order;
  }

  async updateStatus(id: string, dto: UpdateOrderStatusDto) {
    const order = await this.prisma.order.findUnique({ where: { id } });
    if (!order) throw new NotFoundException('Order not found');

    const allowedTransitions = this.VALID_STATUS_TRANSITIONS[order.status];
    if (!allowedTransitions?.has(dto.status)) {
      throw new BadRequestException(
        `لا يمكن تغيير حالة الطلب من "${order.status}" إلى "${dto.status}"`,
      );
    }

    const updateData: any = { status: dto.status };

    if (dto.status === OrderStatus.OUT_FOR_DELIVERY) {
      updateData.pickedUpAt = new Date();
    } else if (dto.status === OrderStatus.DELIVERED) {
      updateData.deliveredAt = new Date();
    }

    const updated = await this.prisma.order.update({
      where: { id },
      data: updateData,
      include: { items: true, deliveryZone: true },
    });

    this.ordersGateway.broadcastOrderStatusUpdate(updated);
    return updated;
  }

  private async calculateItems(
    items: CreateOrderItemDto[],
  ): Promise<CalculatedOrderItem[]> {
    const productIds = [...new Set(items.map((item) => item.productId))];
    const products = await this.prisma.product.findMany({
      where: { id: { in: productIds }, isActive: true },
      include: {
        sizes: true,
        addons: { where: { isActive: true } },
      },
    });

    return items.map((item) => {
      const product = products.find(
        (candidate) => candidate.id === item.productId,
      );
      if (!product) {
        throw new BadRequestException(
          `Product ${item.productId} was not found`,
        );
      }
      if (!product.isAvailable) {
        throw new BadRequestException(
          `Product ${product.nameAr} is not available`,
        );
      }

      const selectedSize = item.sizeId
        ? product.sizes.find((size) => size.id === item.sizeId)
        : product.sizes.find((size) => size.isDefault);

      if (item.sizeId && !selectedSize) {
        throw new BadRequestException(
          `Invalid size for product ${product.nameAr}`,
        );
      }

      const unitBasePrice = selectedSize?.price ?? product.price;
      const requestedAddonIds = item.addonIds ?? [];
      const selectedAddons = requestedAddonIds.map((addonId) => {
        const addon = product.addons.find(
          (candidate) => candidate.id === addonId,
        );
        if (!addon) {
          throw new BadRequestException(
            `Invalid addon for product ${product.nameAr}`,
          );
        }
        return addon;
      });

      const addonTotal = selectedAddons.reduce(
        (sum, addon) => sum.plus(addon.price),
        new Prisma.Decimal(0),
      );
      const unitPrice = unitBasePrice.plus(addonTotal);
      const totalPrice = unitPrice.mul(item.quantity);

      return {
        productId: product.id,
        productName: product.nameAr,
        sizeName: selectedSize?.name,
        quantity: item.quantity,
        unitPrice,
        totalPrice,
        addons: selectedAddons.map((addon) => ({
          id: addon.id,
          nameAr: addon.nameAr,
          nameEn: addon.nameEn,
          price: addon.price.toString(),
        })),
      };
    });
  }

  private async nextOrderNumber(): Promise<string> {
    const result = await this.prisma.$queryRaw<Array<{ value: number }>>`
      INSERT INTO "Counter" ("key", "value")
      VALUES ('order_number', 1)
      ON CONFLICT ("key") DO UPDATE SET "value" = "Counter"."value" + 1
      RETURNING "value"
    `;
    const num = result[0].value.toString().padStart(6, '0');
    return `SC-${num}`;
  }
}
