import { CanActivate, ExecutionContext, Injectable, Logger, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class AdminTokenGuard implements CanActivate {
  private readonly logger = new Logger(AdminTokenGuard.name);

  constructor(
    private readonly configService: ConfigService,
    private readonly jwtService: JwtService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest<{
      headers: Record<string, string | string[] | undefined>;
    }>();
    
    // Strategy 1: Check x-admin-key header (legacy)
    const expectedKey = this.configService.get<string>('app.adminApiKey');
    const adminKey = request.headers['x-admin-key'];
    
    if (expectedKey && adminKey === expectedKey) {
      return true;
    }
    
    // Strategy 2: Check JWT Bearer token (new)
    const authHeader = request.headers['authorization'];
    if (authHeader && typeof authHeader === 'string' && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      try {
        const payload = await this.jwtService.verifyAsync(token);
        if (payload && payload.sub) {
          (request as any).user = payload;
          return true;
        }
      } catch {
        // Token invalid, fall through to rejection
      }
    }
    
    // If no admin key is configured at all, DENY access (fail-closed)
    if (!expectedKey) {
      this.logger.error('ADMIN_API_KEY is not configured! Admin endpoints are BLOCKED. Set the ADMIN_API_KEY environment variable.');
    }
    
    throw new UnauthorizedException('مفتاح المصادقة غير صالح');
  }
}
